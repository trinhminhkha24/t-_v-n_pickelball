# Motion Compare - Mobile App (Expo)

Expo Go-compatible app cho đồ án Motion Compare.
App quay webcam, gửi frame qua WebSocket tới server Python, hiển thị skeleton
+ điểm số realtime.

## Setup

### 1) Cài Node + Expo CLI

```bash
# Trên laptop dev
node -v   # >= 18
npm i -g expo-cli   # không bắt buộc, có thể dùng npx
```

### 2) Cài dependencies

```bash
cd mobile-app
npm install
```

### 3) Sửa server URL

Mở `app.json` (key `expo.extra.serverUrl`) đổi `192.168.1.10` thành IP LAN
của laptop chạy server:

```json
"extra": { "serverUrl": "http://192.168.1.10:8000" }
```

Có thể đổi trực tiếp trong app ở màn hình Home.

### 4) Chạy

```bash
# Khởi động Metro
npx expo start

# Trên điện thoại Android: cài app "Expo Go" từ Play Store, quét QR.
# Trên iOS: dùng camera quét QR (mở trong Expo Go).
```

**Điều kiện bắt buộc:** điện thoại và laptop phải **cùng wifi**, và firewall
laptop phải cho phép port 8000 (Windows Defender thường hỏi lần đầu).

## Cấu trúc

```
mobile-app/
├── App.tsx                  Entry, state-based navigation Home<->Compare
├── app.json                 Expo config (CAMERA permission, serverUrl)
├── package.json
├── tsconfig.json
├── babel.config.js
└── src/
    ├── api/
    │   ├── rest.ts          fetch /presets
    │   └── ws.ts            CompareSocket (WebSocket wrapper)
    ├── lib/
    │   └── coco.ts          17 keypoint indices, edges, scoreToColor (port từ pose_utils.py)
    ├── components/
    │   ├── SkeletonOverlay.tsx   SVG overlay theo per-joint score
    │   └── ScorePanel.tsx        progress + overall + per-joint + feedback
    └── screens/
        ├── HomeScreen.tsx         Chọn server URL + preset
        └── CompareScreen.tsx      Camera + WS + UI realtime
```

## Luồng hoạt động

1. **HomeScreen**:
   - Ping `GET /` của server -> hiện trạng thái OK/Fail.
   - Lấy danh sách preset qua `GET /presets`.
   - User chọn preset, nhấn "Bắt đầu".

2. **CompareScreen**:
   - Xin quyền camera (`expo-camera`).
   - Mở WebSocket `/ws/compare`, gửi `{type:"init", preset, record}`.
   - Khi nhận `ready`: bắt đầu vòng lặp `setInterval` mỗi 125ms (8 FPS):
     - `takePictureAsync({base64:true, quality:0.4})` -> JPEG base64.
     - Gửi `{type:"frame", image, client_ts}`.
     - Đợi response `result` mới gửi frame kế tiếp (`inFlight` flag) -> tránh chất đống.
   - Mỗi `result`: cập nhật state -> SVG vẽ skeleton, panel cập nhật.
   - Bấm **■ Stop**: gửi `{type:"stop"}`, chờ `session`, hiện Alert URL kết quả.

## Hạn chế đã biết của Expo Go + cách khắc phục

| Vấn đề | Cách xử lý |
|---|---|
| `takePictureAsync` chậm (~30-50ms mỗi shot) | Bắn 8 FPS thay vì 30 FPS, đủ cho mục đích so sánh tư thế |
| Không có frame processor như Vision Camera | Chấp nhận, vì on-device pose không phải bài toán ở đây |
| HTTP (không HTTPS) bị Android chặn theo mặc định ở 1 số version | `app.json` không setup cleartext lock, mặc định OK cho Expo Go. Nếu lỗi: dùng ngrok https |
| iOS yêu cầu HTTPS trong production | Dev với Expo Go OK; nếu build standalone cần `NSAppTransportSecurity` exception |

## Tối ưu sau này

- Nếu cảm thấy lag: giảm `quality` xuống 0.3, hoặc giảm xuống 5 FPS.
- Trên iPhone hiệu năng cao: có thể nâng `TARGET_FPS` lên 10-12 trong
  `CompareScreen.tsx`.
- Muốn quay & gửi nhanh hơn: chuyển sang Dev Build + `react-native-vision-camera`
  với frame processor (cần `expo prebuild`, không còn dùng Expo Go).

## Troubleshooting

**App báo "Không kết nối server"**:
- Kiểm tra cùng wifi (cả 2 thiết bị).
- Trên laptop, mở browser http://localhost:8000/ -> phải thấy JSON.
- Trên điện thoại, mở browser http://<IP-laptop>:8000/ -> phải thấy JSON.
  Nếu không: firewall đang chặn port 8000.

**WebSocket open xong rồi close ngay**:
- Server log sẽ in lỗi. Thường do `preset` chưa tồn tại -> chạy
  `build_reference.py` trên server trước.

**Frame quá đen / quá tối / inverted color**:
- Một số máy Android trả base64 PNG thay vì JPEG. `expo-camera` mới mặc định
  JPEG, nếu lỗi: thử thêm `imageType: 'jpg'` vào `takePictureAsync`.

**FPS rất thấp (<3)**:
- Server đang chạy CPU. Kiểm tra log server, nếu mỗi frame mất >300ms thì pose
  inference đang chậm. Dùng GPU hoặc model nhẹ hơn.
